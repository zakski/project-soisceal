//
//  main.m
//  tuPrologClient
//
//  Created by Alberto Sita on 20/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

//Entry point
int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
