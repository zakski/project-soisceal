//
//  AppDelegate.h
//  tuPrologClient
//
//  Created by Alberto Sita on 20/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (NSMutableArray*) tokenizer:(NSString*)url;

@end

