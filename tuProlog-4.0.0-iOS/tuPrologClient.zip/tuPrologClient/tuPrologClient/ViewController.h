//
//  ViewController.h
//  tuPrologClient
//
//  Created by Alberto Sita on 20/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *queryTextView;
@property (weak, nonatomic) IBOutlet UITextView *solutionTextView;
@property (weak, nonatomic) IBOutlet UITextView *errorsTextView;

- (IBAction)cancel:(UIButton *)sender;
- (IBAction)solve:(UIButton *)sender;
- (IBAction)nextSol:(UIButton *)sender;

@end

