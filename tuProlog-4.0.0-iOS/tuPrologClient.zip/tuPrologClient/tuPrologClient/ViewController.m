//
//  ViewController.m
//  tuPrologClient
//
//  Created by Alberto Sita on 20/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

//This method is called when the view is ready
- (void)viewDidLoad {
    [super viewDidLoad];
    CALayer *imageLayer =self.queryTextView.layer;
    [imageLayer setCornerRadius:5];
    [imageLayer setBorderWidth:1];
    imageLayer =self.solutionTextView.layer;
    [imageLayer setCornerRadius:5];
    [imageLayer setBorderWidth:1];
    imageLayer =self.errorsTextView.layer;
    [imageLayer setCornerRadius:5];
    [imageLayer setBorderWidth:1];
    [self.errorsTextView setTextColor:[UIColor redColor]];
}

//Called when the user clicks the cancel button
- (IBAction)cancel:(UIButton *)sender {
    [self.solutionTextView setText: @""];
    [self.queryTextView setText: @""];
    [self.errorsTextView setText: @""];
    NSString *obj = @"";
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:obj forKey:@"currentErrors"];
    [defaults setObject:obj forKey:@"currentSolution"];
    [defaults setObject:obj forKey:@"currentQuery"];
    [defaults synchronize];
    if([self.queryTextView isFirstResponder]){
        [self.queryTextView resignFirstResponder];
    }
}

//Checks if an URL scheme is available
- (BOOL)schemeAvailable:(NSString *)scheme {
    UIApplication *application = [UIApplication sharedApplication];
    NSURL *URL = [NSURL URLWithString:scheme];
    return [application canOpenURL:URL];
}

//Called when the user clicks the solve button
- (IBAction)solve:(UIButton *)sender {
    if([self.queryTextView isFirstResponder]){
        [self.queryTextView resignFirstResponder];
    }
    NSString *queryTxt = [self.queryTextView text];
    if([queryTxt length] == 0){
        [self.errorsTextView setText: @"Empty Prolog Query!"];
    }else{
        BOOL tuPrologMobileInstalled = [self schemeAvailable:@"tuPrologMobile://"];
        if (tuPrologMobileInstalled) {
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSString *query=[self.queryTextView text];
            [defaults setObject:query forKey:@"currentQuery"];
            [defaults synchronize];
            query = [query stringByReplacingOccurrencesOfString:@"&"
                                                           withString:@"&&"];
            NSString *queryURL = [[@"tuPrologMobile://?src=tuPrologMobileClient&query=" stringByAppendingString:query] stringByAppendingString:@"&dst=tuPrologMobileClient"];
            queryURL = [queryURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:queryURL]];
        }
        else{
            UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"INFO" message:@"2p Mobile is not installed!"preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){}];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }
}

//Called when the user clicks the next button
- (IBAction)nextSol:(UIButton *)sender {
    if([self.queryTextView isFirstResponder]){
        [self.queryTextView resignFirstResponder];
    }
    NSString *queryTxt = [self.queryTextView text];
    if([queryTxt length] == 0){
        [self.errorsTextView setText: @"Empty Prolog Query!"];
    }else{
        BOOL tuPrologMobileInstalled = [self schemeAvailable:@"tuPrologMobile://"];
        if (tuPrologMobileInstalled) {
            NSString *queryURL = @"tuPrologMobile://?src=tuPrologMobileClient&nextSol=nextSol&dst=tuPrologMobileClient";
            queryURL = [queryURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:queryURL]];
        }
        else{
            UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"INFO" message:@"2p Mobile is not installed!"preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){}];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }

}

//Senses the touches on the screen
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if([self.queryTextView isFirstResponder]){
        self.errorsTextView.text=@"";
        self.solutionTextView.text=@"";
        [self.queryTextView resignFirstResponder];
    }
}

//Called just before the view appears
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh) name: UIApplicationDidBecomeActiveNotification object:nil];
}

//Called just before the disappearing of the view
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

//Refreshes the GUI
- (void)refresh{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    NSObject *obj=[defaults objectForKey:@"currentQuery"];
    NSString *query = (NSString*) obj;
    obj = [defaults objectForKey:@"currentErrors"];
    NSString *errorsString = (NSString*)obj;
    obj = [defaults objectForKey:@"currentSolution"];
    NSString *solutionString = (NSString*)obj;
    [self.queryTextView setText:query];
    [self.errorsTextView setText:errorsString];
    [self.solutionTextView setText:solutionString];
}

@end
