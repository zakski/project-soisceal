//
//  AppDelegate.m
//  tuPrologClient
//
//  Created by Alberto Sita on 20/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import <WatchConnectivity/WatchConnectivity.h>

@interface AppDelegate () <WCSessionDelegate>

@end

@implementation AppDelegate

WCSession *session;

//Checks if an Apple Watch is paired to the iPhone and starts a session to exchange data
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    if ([WCSession isSupported]) {
        session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
    }
    return YES;
}

//Gets the tokens from the input URL
- (NSMutableArray*) tokenizer:(NSString*)url {
    int i;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSString *token = @"";
    for(i=0; i<[url length]; i++){
        if([url characterAtIndex:i] == '&'){
            if((i+1<[url length] && [url characterAtIndex:i+1] =='&')||([url characterAtIndex:i-1] == '&')){
                NSString *ch = [NSString stringWithFormat:@"%c", [url characterAtIndex:i]];
                token = [token stringByAppendingString:ch];
            }else{
                [array addObject:token];
                token = @"";
            }
        }else{
            NSString *ch = [NSString stringWithFormat:@"%c", [url characterAtIndex:i]];
            token = [token stringByAppendingString:ch];
        }
    }
    if([token length] != 0){
       [array addObject:token];
    }
    return array;
}

//Handles the URL requests
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    NSString *urlWithPercent = [url query];
    NSString *text = [urlWithPercent stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableArray *urlSubParts = [self tokenizer:text];
    NSString *action = [[[urlSubParts objectAtIndex:0] componentsSeparatedByString:@"="] objectAtIndex:0];
    int tokens = (int)[urlSubParts count];
    if(tokens==1){
        if ([action caseInsensitiveCompare:@"error"] == NSOrderedSame) {
            NSString *errors =[[[urlSubParts objectAtIndex:0] componentsSeparatedByString:@"="]objectAtIndex:1];
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:errors forKey:@"currentErrors"];
            [defaults synchronize];
        }
    }else if(tokens==2){
        if ([action caseInsensitiveCompare:@"nextSol"] == NSOrderedSame) {
            NSString *solution =[[[urlSubParts objectAtIndex:0] componentsSeparatedByString:@"="]objectAtIndex:1];
            solution = [solution stringByReplacingOccurrencesOfString:@"&&" withString:@"&"];
            NSString *version = [[[urlSubParts objectAtIndex:1] componentsSeparatedByString:@"="]objectAtIndex:1];
            NSString *sol=[[solution stringByAppendingString:@"\nServer Engine: "]stringByAppendingString: version];
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            [defaults setObject:sol forKey:@"currentSolution"];
            [defaults synchronize];
            [self sendData];
        }
    }else{
        NSString *solution =[[[urlSubParts objectAtIndex:0] componentsSeparatedByString:@"="]objectAtIndex:1];
        solution = [solution stringByReplacingOccurrencesOfString:@"&&" withString:@"&"];
        NSString *errors = [[[urlSubParts objectAtIndex:1] componentsSeparatedByString:@"="]objectAtIndex:1];
        NSString *version = [[[urlSubParts objectAtIndex:2] componentsSeparatedByString:@"="]objectAtIndex:1];
        NSString *sol=@"";
        if([solution length]==0){
            sol=[[solution stringByAppendingString:@"Server Engine: "]stringByAppendingString: version];
        }else{
            sol=[[solution stringByAppendingString:@"\nServer Engine: "]stringByAppendingString: version];
        }
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:errors forKey:@"currentErrors"];
        [defaults setObject:sol forKey:@"currentSolution"];
        [defaults synchronize];
        [self sendData];
    }
    return YES;
}

//Sends data to the Apple Watch
- (void)sendData{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    NSObject *obj=[defaults objectForKey:@"currentQuery"];
    NSString *query = (NSString*) obj;
    obj = [defaults objectForKey:@"currentErrors"];
    NSString *errorsString = (NSString*)obj;
    obj = [defaults objectForKey:@"currentSolution"];
    NSString *solutionString = (NSString*)obj;
    NSError *error;
    if(session != nil){
    [session updateApplicationContext:@{@"currentQuery": query, @"currentErrors":errorsString, @"currentSolution":solutionString} error:&error];
    }
}

@end

