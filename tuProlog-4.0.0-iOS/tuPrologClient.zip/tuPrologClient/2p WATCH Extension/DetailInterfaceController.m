//
//  DetailInterfaceController.m
//  tuPrologClient
//
//  Created by Alberto Sita on 22/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import "DetailInterfaceController.h"

@interface DetailInterfaceController ()

@end

@implementation DetailInterfaceController

//Called when the controller is awaken
- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    NSInteger num= [defaults integerForKey:@"currentContext"];
    long numQ = (long)num;
    NSString *qKey = [@"q" stringByAppendingString:[[NSNumber numberWithInt:(long)numQ] stringValue]];
    NSString *eKey = [@"errors" stringByAppendingString: [[NSNumber numberWithInt:(long)numQ] stringValue]];
    NSString *sKey = [@"solution" stringByAppendingString: [[NSNumber numberWithInt:(long)numQ] stringValue]];
    
    NSString *query = [defaults objectForKey:qKey];
    NSString *errors = [defaults objectForKey:eKey];
    NSString *sol = [defaults objectForKey:sKey];
    
    if([query length]==0)
    {
        [self.detail setText:@"empty :-)"];
    }else{
        if([errors length]!=0)
        {
            NSString *text =[[[@"Query: " stringByAppendingString:query] stringByAppendingString:@"\n "] stringByAppendingString:errors];
            [self.detail setText:text];
            
        }else{
             NSString *text =[[[@"Query: " stringByAppendingString:query] stringByAppendingString:@"\nSolution: "] stringByAppendingString:sol];
            [self.detail setText:text];
        }
    }
}

//Not used
- (void)willActivate {
    [super willActivate];
}

//Not used
- (void)didDeactivate {
    [super didDeactivate];
}

@end



