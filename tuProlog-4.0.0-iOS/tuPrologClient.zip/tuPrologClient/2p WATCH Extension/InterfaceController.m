//
//  InterfaceController.m
//  2p WATCH Extension
//
//  Created by Alberto Sita on 21/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import "InterfaceController.h"
#import <WatchConnectivity/WatchConnectivity.h>


@interface InterfaceController() <WCSessionDelegate>

@end

@implementation InterfaceController

//Called when the controller is awaken
- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    [self configure];
}

//Configures the button aspect
- (void) configure{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    long i;
    for(i=0; i<10; i++){
        NSString *qKey = [@"q" stringByAppendingString:[[NSNumber numberWithInt:i] stringValue]];
        NSObject *obj = [defaults objectForKey:qKey];
        NSString *q = (NSString*)obj;
        if(q != nil){
            q =[@"?- " stringByAppendingString:q];
            [self configureButtons:i :q];
        }
    }
}

//Configures the buttons
- (void) configureButtons:(long)numberQ :(NSString*)q{
    NSLog(@"%ld", numberQ);
    switch(numberQ){
        case 0:
            [self.firstB setTitle:q];
            break;
        case 1:
            [self.secondB setTitle:q];
            break;
        case 2:
            [self.thirdB setTitle:q];
            break;
        case 3:
            [self.fourthB setTitle:q];
            break;
        case 4:
            [self.fifthB setTitle:q];
            break;
        case 5:
            [self.sixthB setTitle:q];
            break;
        case 6:
            [self.seventhB setTitle:q];
            break;
        case 7:
            [self.eigthB setTitle:q];
            break;
        case 8:
            [self.ninethB setTitle:q];
            break;
        case 9:
            [self.tenthB setTitle:q];
            break;
    }
}

//Called when the extension is starting
- (void)willActivate {
    [super willActivate];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    if(![defaults boolForKey:@"isInitialized"]){
        [defaults setBool:YES forKey:@"isInitialized"];
        [defaults setInteger:0 forKey:@"numQ"];
        [defaults synchronize];
    }
    if ([WCSession isSupported]) { //Opens a session
        WCSession *session = [WCSession defaultSession];
        session.delegate = self;
        [session activateSession];
    }
    [self configure];
}

//Not used
- (void)didDeactivate {
    [super didDeactivate];
}

//Called when the iPhone sends data to the watch
- (void) session:(nonnull WCSession *)session didReceiveApplicationContext:(nonnull NSDictionary<NSString *,id> *)applicationContext {
    NSString* q = [applicationContext objectForKey:@"currentQuery"];
    NSString* errors = [applicationContext objectForKey:@"currentErrors"];
    NSString* sol = [applicationContext objectForKey:@"currentSolution"];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults synchronize];
    NSInteger num= [defaults integerForKey:@"numQ"];
    long numQ = (long)num;
    NSString *qKey = [@"q" stringByAppendingString:[[NSNumber numberWithInt:(long)numQ] stringValue]];
    NSString *eKey = [@"errors" stringByAppendingString: [[NSNumber numberWithInt:(long)numQ] stringValue]];
    NSString *sKey = [@"solution" stringByAppendingString: [[NSNumber numberWithInt:(long)numQ] stringValue]];
    [defaults setObject:q forKey:qKey];
    [defaults setObject:errors forKey:eKey];
    [defaults setObject:sol forKey:sKey];
        q =[@"?- " stringByAppendingString:q];
    [self configureButtons:(long)numQ :q];
    numQ = numQ + 1;
    if(numQ==10){
        numQ=0;
    }
    [defaults setInteger:numQ forKey:@"numQ"];
    [defaults synchronize];
}

//Buttons actions
- (IBAction)b1:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 0;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b2:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 1;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b3:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 2;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b4:(WKInterfaceButton *)
sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 3;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b5:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 4;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b6:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 5;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b7:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 6;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b8:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 7;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b9:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 8;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
- (IBAction)b10:(WKInterfaceButton *)sender{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger numb = 9;
    [defaults setInteger:numb forKey:@"currentContext"];
    [self pushControllerWithName:@"details" context:nil];
    [defaults synchronize];
}
//

@end



