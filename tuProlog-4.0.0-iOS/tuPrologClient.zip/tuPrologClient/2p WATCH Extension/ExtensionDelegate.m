//
//  ExtensionDelegate.m
//  2p WATCH Extension
//
//  Created by Alberto Sita on 21/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import "ExtensionDelegate.h"

@implementation ExtensionDelegate

//Not used
- (void)applicationDidFinishLaunching {
}

//Not used
- (void)applicationDidBecomeActive {
}

//Not used
- (void)applicationWillResignActive {
}

@end
