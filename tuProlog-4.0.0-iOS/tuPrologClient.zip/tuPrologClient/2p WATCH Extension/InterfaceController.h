//
//  InterfaceController.h
//  2p WATCH Extension
//
//  Created by Alberto Sita on 21/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface InterfaceController : WKInterfaceController

@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *firstB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *secondB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *thirdB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *fourthB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *fifthB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *sixthB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *seventhB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *eigthB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *ninethB;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceButton *tenthB;

- (IBAction)b1:(WKInterfaceButton *)sender;
- (IBAction)b2:(WKInterfaceButton *)sender;
- (IBAction)b3:(WKInterfaceButton *)sender;
- (IBAction)b4:(WKInterfaceButton *)sender;
- (IBAction)b5:(WKInterfaceButton *)sender;
- (IBAction)b6:(WKInterfaceButton *)sender;
- (IBAction)b7:(WKInterfaceButton *)sender;
- (IBAction)b8:(WKInterfaceButton *)sender;
- (IBAction)b9:(WKInterfaceButton *)sender;
- (IBAction)b10:(WKInterfaceButton *)sender;

@end
