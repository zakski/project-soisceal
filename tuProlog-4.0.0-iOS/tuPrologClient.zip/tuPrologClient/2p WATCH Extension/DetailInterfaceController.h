//
//  DetailInterfaceController.h
//  tuPrologClient
//
//  Created by Alberto Sita on 22/11/15.
//  Copyright © 2015 Alberto Sita. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface DetailInterfaceController : WKInterfaceController

@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *detail;

@end
